# ysn-archive-retrieval
Archive Retrieval Project for YS News
Allows the user to select a date from a calendar GUI and retrieves the appropriate issue for that date.

To use on a WordPress website: place this directory (with all the files) in the ```wp-content``` folder of your website.
